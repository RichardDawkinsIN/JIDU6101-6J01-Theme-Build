#!/bin/bash
set -e

REPO_DIR=$(pwd)

sudo apt update
sudo apt install -y build-essential clang flex bison g++ gawk \
gcc-multilib g++-multilib gettext git libncurses5-dev libssl-dev \
python3-setuptools rsync swig unzip zlib1g-dev file wget ccache tree

git clone https://github.com/openwrt/openwrt.git
cd openwrt

git checkout v25.12.5

git config --global user.email "ci@build.local"
git config --global user.name "CI Builder"

# Fetch the PR
git fetch origin pull/23510/head:pr-23510 --force

# Get only Jio-related commits and cherry-pick them dynamically
# (Some commits, e.g. JIDU6101 support, are already merged into mainline OpenWrt.
#  We try each commit individually and skip ones that are already applied or conflict,
#  instead of failing the whole build.)
JIO_COMMITS=$(git log pr-23510 --oneline --grep="jio\|jidu" --regexp-ignore-case --format="%H" | tac | \
  grep -v $(git log --format="%H" | head -100 | tr '\n' '\|' | sed 's/|$//'))

for commit in $JIO_COMMITS; do
  echo "Attempting to cherry-pick $commit"
  if git cherry-pick -X theirs "$commit"; then
    echo "  -> applied $commit"
  else
    echo "  -> skipping $commit (already applied or conflict)"
    git cherry-pick --abort 2>/dev/null || git cherry-pick --skip 2>/dev/null || true
  fi
done


echo "==============================adding initramfs-factory.ubi artifact to JIDU6101 and JIDU6J01=============================="
# Add initramfs-factory.ubi artifact to JIDU6101 and JIDU6J01
FILOGIC_MK="target/linux/mediatek/image/filogic.mk"

for DEV in jiorouter_ax6000-jidu6101 jiorouter_ax6000-jidu6j01; do
  # Skip if this device already has the artifact (idempotent)
  if awk "/^define Device\/${DEV}\$/,/^endef/" "$FILOGIC_MK" | grep -q "initramfs-factory.ubi"; then
    echo "[$DEV] initramfs-factory.ubi already present, skipping"
    continue
  fi

  echo "[$DEV] adding initramfs-factory.ubi artifact"

  # Insert the artifact block before the sysupgrade line, but ONLY inside this device's block
  awk -v dev="$DEV" '
    $0 == "define Device/" dev { indev=1 }
    indev && /^  IMAGE\/sysupgrade\.bin := sysupgrade-tar \| append-metadata$/ {
      print "ifeq ($(IB),)"
      print "ifneq ($(CONFIG_TARGET_ROOTFS_INITRAMFS),)"
      print "  ARTIFACTS := initramfs-factory.ubi"
      print "  ARTIFACT/initramfs-factory.ubi := append-image-stage initramfs-kernel.bin | ubinize-kernel"
      print "endif"
      print "endif"
      indev=0
    }
    { print }
  ' "$FILOGIC_MK" > "${FILOGIC_MK}.tmp" && mv "${FILOGIC_MK}.tmp" "$FILOGIC_MK"
done
echo "==============================finished adding initramfs-factory.ubi artifact to JIDU6101 and JIDU6J01=============================="


cat <<-EOF >> feeds.conf.default
src-git --root=feeds fantastic_packages https://github.com/fantastic-packages/packages.git;master
EOF

./scripts/feeds update -a
./scripts/feeds install -a

# Copy config and inject ccache dir dynamically
cp $REPO_DIR/${DEVICE_CONFIG} .config

make defconfig

echo "==============================adding fantastic package feeds=============================="
# --- Add fantastic-packages runtime feed (baked into firmware) ---
VER="25.12"
ARCH="aarch64_cortex-a53"
KEYID="20241123170031"   # from the grep above, WITHOUT the .pub extension

mkdir -p files/etc/apk/repositories.d
mkdir -p files/etc/apk/keys

# Correct feed URLs (github.io, not openwrt.org)
cat > files/etc/apk/repositories.d/customfeeds.list <<EOF
https://fantastic-packages.github.io/releases/${VER}/packages/${ARCH}/luci/packages.adb
https://fantastic-packages.github.io/releases/${VER}/packages/${ARCH}/packages/packages.adb
https://fantastic-packages.github.io/releases/${VER}/packages/${ARCH}/special/packages.adb
EOF

# Public key so apk trusts the feed (no --allow-untrusted needed)
curl -sSL -o "files/etc/apk/keys/${KEYID}.pem" \
  "https://fantastic-packages.github.io/releases/${VER}/${KEYID}.pub"

# Fail loudly if the key didn't download — don't ship a feed with no key
if [ ! -s "files/etc/apk/keys/${KEYID}.pem" ]; then
  echo "ERROR: fantastic-packages key download failed or empty"
  exit 1
fi
echo "Successfully added fantastic-packages feed with key ${KEYID}.pem"
echo "==============================finished adding fantastic package feeds=============================="

echo "==============================adding custom theme packages=============================="
mkdir -p files/etc/custom-pkgs
cp "$REPO_DIR/custom-pkgs/"*.apk files/etc/custom-pkgs/
echo "==============================finished adding custom theme packages=============================="

echo "==============================adding custom uci-defaults script=============================="
mkdir -p files/etc/uci-defaults

cat > files/etc/uci-defaults/99-custom-config <<'EOF'
#!/bin/sh
# /etc/uci-defaults/99-jiorouter-setup
exec >/tmp/setup.log 2>&1

# =========================================================
# WIFI ON — 2.4GHz + 5GHz, no password
# =========================================================
uci set wireless.@wifi-device[0].disabled='0'
uci set wireless.@wifi-iface[0].disabled='0'
uci set wireless.@wifi-device[1].disabled='0'
uci set wireless.@wifi-iface[1].disabled='0'
uci commit wireless
wifi reload

# =========================================================
# Custom LED script (RGB mixing + 100M port warning)
# =========================================================
cat > /usr/bin/led-wan << 'LEDEOF'
#!/bin/sh
trap 'exit 0' TERM INT

PING_TARGETS="1.1.1.1 8.8.8.8"
STATE_FILE="/tmp/router_led_state"
CHECK_PORTS="wan lan1 lan2 lan3 lan4"

set_led() {
    color="$1"
    mode="$2"

    r=0; g=0; b=0
    case "$color" in
        red)              r=1 ;;
        green)            g=1 ;;
        blue)             b=1 ;;
        yellow|amber)     r=1; g=1 ;;
        cyan)             g=1; b=1 ;;
        magenta|purple)   r=1; b=1 ;;
        white)            r=1; g=1; b=1 ;;
    esac

    for c in red green blue; do
        path="/sys/class/leds/${c}:status"
        [ -d "$path" ] || continue

        val=0
        [ "$c" = "red" ]   && val=$r
        [ "$c" = "green" ] && val=$g
        [ "$c" = "blue" ]  && val=$b

        if [ "$val" -eq 1 ] && [ "$mode" != "off" ]; then
            if [ "$mode" = "flash" ]; then
                echo timer > "${path}/trigger" 2>/dev/null
                echo 500 > "${path}/delay_on" 2>/dev/null
                echo 500 > "${path}/delay_off" 2>/dev/null
            else
                echo none > "${path}/trigger" 2>/dev/null
                echo 255 > "${path}/brightness" 2>/dev/null
            fi
        else
            echo none > "${path}/trigger" 2>/dev/null
            echo 0 > "${path}/brightness" 2>/dev/null
        fi
    done
}

check_internet() {
    for target in $PING_TARGETS; do
        if ping -c 1 -W 2 "$target" >/dev/null 2>&1; then
            return 0
        fi
    done
    return 1
}

check_port_warning() {
    for port in $CHECK_PORTS; do
        if [ -d "/sys/class/net/$port" ]; then
            speed=$(cat "/sys/class/net/$port/speed" 2>/dev/null)
            state=$(cat "/sys/class/net/$port/operstate" 2>/dev/null)
            if [ "$state" = "up" ] && [ "$speed" = "100" ]; then
                return 0
            fi
        fi
    done
    return 1
}

is_upgrading() {
    pgrep -f "sysupgrade" >/dev/null 2>&1 && return 0
    [ -e /tmp/sysupgrade ] && return 0
    [ -e /overlay/.sysupgrade ] && return 0
    [ -e /tmp/.failsafe ] && return 0
    [ -f /tmp/sysupgrade.always_force_backup ] && return 0
    ls /tmp/sysupgrade-* >/dev/null 2>&1 && return 0
    return 1
}

while true; do
    if is_upgrading; then
        set_led none off
        exit 0
    fi

    if check_internet; then
        if check_port_warning; then
            TARGET_COLOR="yellow"
            TARGET_MODE="flash"
        else
            TARGET_COLOR="green"
            TARGET_MODE="solid"
        fi
    else
        TARGET_COLOR="red"
        TARGET_MODE="flash"
    fi

    NEW_STATE="${TARGET_COLOR}_${TARGET_MODE}"
    OLD_STATE=$(cat "$STATE_FILE" 2>/dev/null)

    if [ "$NEW_STATE" != "$OLD_STATE" ]; then
        set_led "$TARGET_COLOR" "$TARGET_MODE"
        echo "$NEW_STATE" > "$STATE_FILE"
    fi

    sleep 5
done
LEDEOF
chmod +x /usr/bin/led-wan

# =========================================================
# Init.d service with procd
# =========================================================
cat > /etc/init.d/ledwan << 'INITEOF'
#!/bin/sh /etc/rc.common
START=99
STOP=10
USE_PROCD=1
start_service() {
    procd_open_instance
    procd_set_param command /usr/bin/led-wan
    procd_set_param respawn
    procd_close_instance
}
stop_service() {
    killall led-wan 2>/dev/null
}
restart() {
    stop
    start
}
INITEOF
chmod +x /etc/init.d/ledwan
/etc/init.d/ledwan enable
/etc/init.d/ledwan start

# =========================================================
# CUSTOM MODEL NAME (auto-detected at runtime)
# =========================================================
cat > /etc/init.d/custom-model << 'MODELEOF'
#!/bin/sh /etc/rc.common

START=95

start() {
    mkdir -p /tmp/sysinfo

    . /lib/functions.sh
    BOARD=$(board_name)
    MODEL=""

    case "$BOARD" in
    jiorouter,ax6000-jidu6101)
        MODEL="JioRouter AX6000 JIDU6101"
        ;;
    jiorouter,ax6000-jidu6j01)
        mfg_part="$(grep -m1 MFG /proc/mtd | cut -d: -f1)"
        DETECTED=""
        if [ -n "$mfg_part" ]; then
            DETECTED=$(strings "/dev/${mfg_part}" 2>/dev/null | grep -o -m1 'JIDU[0-9A-Z][0-9A-Z]*')
        fi
        if [ -n "$DETECTED" ]; then
            MODEL="JioRouter AX6000 ${DETECTED}"
        else
            MODEL="JioRouter AX6000 JIDU6201/6401/6601/6701"
        fi
        ;;
    *)
        MODEL="JioRouter AX6000"
        ;;
    esac

    echo "$MODEL" > /tmp/sysinfo/model
}
MODELEOF
chmod +x /etc/init.d/custom-model
/etc/init.d/custom-model enable
/etc/init.d/custom-model start

# =========================================================
# CUSTOM BANNER
# =========================================================
cat > /etc/banner <<'BANNEREOF'
=============================================================
#   #  ###  #   #  ###  #   # ####   ###      # ##### #   #
## ## #   # ##  # #   # #   # #   # #   #     #   #   ##  #
# # # ##### # # # ##### #   # ####  #####     #   #   # # #
#   # #   # #  ## #   #  # #  #  #  #   # #   #   #   #  ##
#   # #   # #   # #   #   #   #   # #   #  ###  ##### #   #
=============================================================
                      Version 25.12.5
                Developer @RichardDawkinsIN
=============================================================
BANNEREOF

# =========================================================
# CUSTOM THEME (Aurora)
# =========================================================
if [ -f /etc/custom-pkgs/luci-theme-aurora.apk ]; then
    apk add --allow-untrusted /etc/custom-pkgs/luci-theme-aurora.apk
fi
if [ -f /etc/custom-pkgs/luci-app-aurora-config.apk ]; then
    apk add --allow-untrusted /etc/custom-pkgs/luci-app-aurora-config.apk
fi

uci set luci.main.mediaurlbase='/luci-static/aurora'
uci commit luci

exit 0
EOF

chmod +x files/etc/uci-defaults/99-custom-config
echo "==============================finished adding custom uci-defaults script=============================="

echo "==============================adding custom banner=============================="
mkdir -p files/etc

cat > files/etc/banner <<'EOF'
=============================================================
#   #  ###  #   #  ###  #   # ####   ###      # ##### #   #
## ## #   # ##  # #   # #   # #   # #   #     #   #   ##  #
# # # ##### # # # ##### #   # ####  #####     #   #   # # #
#   # #   # #  ## #   #  # #  #  #  #   # #   #   #   #  ##
#   # #   # #   # #   #   #   #   # #   #  ###  ##### #   #
=============================================================
                      Version 25.12.5
                Developer @RichardDawkinsIN
=============================================================
EOF
echo "==============================finished adding custom banner=============================="



make -j$(nproc)

echo "Build completed successfully! Artifacts are located in bin/targets/mediatek/filogic/"
